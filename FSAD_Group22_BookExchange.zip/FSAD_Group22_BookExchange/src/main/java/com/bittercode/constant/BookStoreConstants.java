package com.bittercode.constant;

public interface BookStoreConstants {
	public static String CONTENT_TYPE_TEXT_HTML = "text/html";
	
	
}
